"use client";

import { Download, Expand, ExternalLink, Printer } from "lucide-react";
import { useRef } from "react";

export function DocumentPdfViewer({
  src,
  title,
  downloadHref
}: {
  src: string;
  title: string;
  downloadHref: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);

  async function enterFullscreen() {
    await containerRef.current?.requestFullscreen?.();
  }

  return (
    <div ref={containerRef} className="pdf-viewer min-w-0 bg-zinc-100">
      <div className="sticky top-[57px] z-20 border-b bg-white/95 p-2 shadow-sm backdrop-blur sm:top-[65px]">
        <div className="flex flex-wrap items-center justify-center gap-2">
          <ToolbarButton label="Fullscreen" onClick={enterFullscreen}>
            <Expand size={18} />
          </ToolbarButton>
          <ToolbarButton label="Print" onClick={() => window.print()}>
            <Printer size={18} />
          </ToolbarButton>
          <a
            className="touch-target inline-flex items-center justify-center gap-2 rounded-lg border bg-white px-3 text-sm font-semibold text-emeraldInk"
            href={src}
            target="_blank"
            rel="noreferrer"
          >
            <ExternalLink size={18} /> Open separately
          </a>
          <a
            className="touch-target inline-flex items-center justify-center gap-2 rounded-lg bg-palm px-3 text-sm font-semibold text-white"
            href={downloadHref}
            download
          >
            <Download size={18} /> Download
          </a>
        </div>
        <p className="mt-1 text-center text-xs text-emerald-800">
          Use the PDF toolbar for page navigation, zoom, search, fit-to-width and print.
        </p>
      </div>

      <div className="mx-auto min-h-[70vh] max-w-6xl overflow-hidden bg-zinc-200 p-2 sm:p-4">
        <iframe
          src={`${src}#toolbar=1&navpanes=0&view=FitH`}
          title={`${title} PDF reader`}
          className="h-[76vh] min-h-[560px] w-full border-0 bg-white"
          loading="eager"
        />
        <noscript>
          <p className="p-6 text-center">
            JavaScript is required for the online reader. <a href={downloadHref}>Download the document instead.</a>
          </p>
        </noscript>
      </div>
    </div>
  );
}

function ToolbarButton({
  label,
  children,
  onClick
}: {
  label: string;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className="touch-target inline-flex items-center justify-center rounded-lg border bg-white px-3 text-sm font-semibold text-emeraldInk transition hover:bg-emerald-50"
    >
      {children}
    </button>
  );
}
