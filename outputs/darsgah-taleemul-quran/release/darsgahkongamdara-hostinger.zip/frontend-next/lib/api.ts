"use client";

import axios from "axios";

function normalizeApiUrl(value?: string) {
  const raw = (value || "http://localhost:5000/api").replace(/\/+$/, "");
  return raw.endsWith("/api") ? raw : `${raw}/api`;
}

export const API_URL = normalizeApiUrl(process.env.NEXT_PUBLIC_API_URL);

export const api = axios.create({ baseURL: API_URL, timeout: 8000, withCredentials: true });

declare global {
  interface Window {
    AndroidDownloader?: {
      download: (url: string, filename: string, mimeType: string, token: string) => void;
    };
  }
}

api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("darsgah_token");
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export async function downloadFile(path: string, filename: string) {
  const token = typeof window !== "undefined" ? localStorage.getItem("darsgah_token") || "" : "";
  if (typeof window !== "undefined" && window.AndroidDownloader) {
    const url = `${API_URL}${path.startsWith("/") ? path : `/${path}`}`;
    window.AndroidDownloader.download(url, filename, "application/pdf", token);
    return;
  }
  const { data } = await api.get(path, { responseType: "blob" });
  const url = window.URL.createObjectURL(new Blob([data]));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}
